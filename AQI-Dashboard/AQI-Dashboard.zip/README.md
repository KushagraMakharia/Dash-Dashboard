# Dash-Dashboard
Real Time Dash Dashboard

Data: Run data.py

Run: python main.y