#!/bin/bash
# set_permissions.sh

chmod +x /home/ec2-user/app/scripts/*.sh
